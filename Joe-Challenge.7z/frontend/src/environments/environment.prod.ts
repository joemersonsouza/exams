export const environment = {
  production: true,
  baseUrl: 'http://azure-function/api'
};
