export class Car {
    id?: string;
    maker: string;
    model_name: string;
    year: number;
    color: string;
    monthlyPrice: number;
    availableDate: Date;
}