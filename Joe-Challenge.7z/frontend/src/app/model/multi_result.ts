import { Car } from "./car";

export interface CarMultiResult {
    cars: Car[]
    totalPage: number
}